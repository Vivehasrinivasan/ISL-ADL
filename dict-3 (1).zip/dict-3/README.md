# dict 3

A Pen created on CodePen.

Original URL: [https://codepen.io/shiraya/pen/myeMYwZ](https://codepen.io/shiraya/pen/myeMYwZ).

